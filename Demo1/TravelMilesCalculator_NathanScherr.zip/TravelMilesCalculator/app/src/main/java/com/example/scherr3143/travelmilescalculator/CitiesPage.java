package com.example.scherr3143.travelmilescalculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class CitiesPage extends AppCompatActivity {

    private Spinner citySpinner1;
    private Spinner citySpinner2;
    private EditText etCode;
    private String discountCode;
    private String cityFrom;
    private String cityTo;
    private int intRequestCode;
    private String distance;
    private String ticketPrice;
    private String bonusMile;
    private TextView tvDistanceResult;
    private TextView tvBonusMilesResult;
    private TextView tvTicketPriceResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maincitiespage_relativelayout);

        Spinner dropdownFrom = (Spinner)findViewById(R.id.tvSpinnerItem1);
        String[] itemsFrom = new String[]{"Regina", "Edmonton", "Vancouver"};
        ArrayAdapter<String> adapterFrom = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, itemsFrom);
        dropdownFrom.setAdapter(adapterFrom);

        Spinner dropdownTo = (Spinner)findViewById(R.id.tvSpinnerItem2);
        String[] itemsTo = new String[]{"Edmonton", "Vancouver", "Regina"};
        ArrayAdapter<String> adapterTo = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, itemsTo);
        dropdownTo.setAdapter(adapterTo);

        etCode = (EditText) findViewById(R.id.etDiscountCode);
        citySpinner1 = (Spinner) findViewById(R.id.tvSpinnerItem1);
        citySpinner2 = (Spinner) findViewById(R.id.tvSpinnerItem2);

        discountCode = etCode.toString();
        cityFrom = citySpinner1.getSelectedItem().toString();
        cityTo = citySpinner2.getSelectedItem().toString();

    }

    public void activateTravelResults(View view){

        Intent launchResults = new Intent(this, TravelResultsActivity.class);
        intRequestCode = 1;

        launchResults.putExtra("CityFrom",cityFrom);
        launchResults.putExtra("CityTo",cityTo);
        launchResults.putExtra("DiscountCode",discountCode);

        startActivityForResult(launchResults, intRequestCode);
    }

    @Override
    protected void onActivityResult(int intRequestCode, int intResultCode, Intent returnResults){
        super.onActivityResult(intRequestCode,intResultCode,returnResults);

        if(intRequestCode == 1){
            if(intResultCode==1){
                Intent intent = getIntent();

                cityFrom = intent.getStringExtra("CityFrom");
                cityTo = intent.getStringExtra("CityTo");
                discountCode = intent.getStringExtra("DiscountCode");
                distance = intent.getStringExtra("Distance");
                ticketPrice = intent.getStringExtra("TicketPrice");
                bonusMile = intent.getStringExtra("BonusMiles");

                tvDistanceResult.setText(distance);
                tvBonusMilesResult.setText(bonusMile);
                tvTicketPriceResult.setText(ticketPrice);
                citySpinner1.setSelection(1);
                citySpinner2.setSelection(1);
                etCode.setText(discountCode);

            }
        }
    }

}
